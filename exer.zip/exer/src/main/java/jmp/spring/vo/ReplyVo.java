package jmp.spring.vo;

import lombok.Data;

@Data
public class ReplyVo {

	int rno;
	int vno;
	int re_rno;
	String id;
	String content;
	String writer;
	String regdate;
	String updatedate;
	
}
