package jmp.spring.vo;

import lombok.Data;

@Data
public class ReplyVo {

	int rno;
	int bno;
	String reply;
	String replyer;
	String replydate;
	String updatedate;
	
}
