package jmp.spring.vo;

import lombok.Data;

@Data
public class ReviewVo {

	int cno;
	int rno;
	String id;
	String content;
	String writer;
	String regdate;
	int rating;
	
	
	
}
