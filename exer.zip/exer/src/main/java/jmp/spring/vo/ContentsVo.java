package jmp.spring.vo;

import lombok.Data;

@Data
public class ContentsVo {
 int cnum ;
 String cname;
 String story;
 String cast;
 String tags;
 String bc;
 String agelimit;
 String end;
 
 String puploadpath;
 String pname;
}
